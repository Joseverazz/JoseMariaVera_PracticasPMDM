package com.example.t06_recicler.adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.t06_recicler.R;
import com.example.t06_recicler.utils.Contacto;

import java.util.ArrayList;

public class AdaptadorRecycler extends RecyclerView.Adapter<AdaptadorRecycler.MyHolder> {
    private ArrayList<Contacto> listaContactos;
    private Context context;


    public AdaptadorRecycler(ArrayList<Contacto> listaContactos, Context context) {
        this.listaContactos = listaContactos;
        this.context = context;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_lista, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        //Se pinta cada una de las filas
        Contacto contacto = listaContactos.get(position);
        holder.textoNombre.setText(contacto.getNombre());
        holder.textoTelefono.setText(String.valueOf(contacto.getTelefono()));
        if (contacto.getImagen() != -1){
            holder.imagen.setImageResource(contacto.getImagen());
        }
        holder.linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context,contacto.getDireccion().toString(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaContactos.size();
    }

    class MyHolder extends RecyclerView.ViewHolder{
     TextView textoNombre, textoTelefono;
     ImageView imagen;
     LinearLayout linear;
     public MyHolder(@NonNull View itemView) {
         super(itemView);
         textoNombre = itemView.findViewById(R.id.nombre_fila);
         textoTelefono = itemView.findViewById(R.id.telefono_fila);
         imagen = itemView.findViewById(R.id.imagen_fila);
         linear = itemView. findViewById(R.id.linear_fila_recycler);
     }
 }
}
